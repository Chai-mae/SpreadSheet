#ifndef TEXTEDITOR_H
#define TEXTEDITOR_H

#include <QMainWindow>
#include <QFile>
#include <QMessageBox>
#include <QFileDialog>
#include <QTextStream>
#include <QSaveFile>



QT_BEGIN_NAMESPACE
namespace Ui { class textEditor; }
QT_END_NAMESPACE

class textEditor : public QMainWindow
{
    Q_OBJECT

public:
    textEditor(QWidget *parent = nullptr);
    ~textEditor();
protected:
    bool saveFile(const QString &filename);
    void setCurrentFile(const QString &filename);

private slots:
    void on_action_Exit_triggered();

    void on_actionNew_triggered();

    void on_actionOpen_triggered();

    void on_action_Copy_triggered();

    void on_action_Paste_triggered();

    void on_action_Cut_triggered();

    void on_action_About_triggered();

    void on_actionAbout_Qt_triggered();

    bool Save();

    bool SaveAs();

private:
    Ui::textEditor *ui;
    QString currentFile;
};
#endif // TEXTEDITOR_H
