#include "spreadsheet.h"
#include<QPixmap>
#include<QMessageBox>
#include<QStatusBar>
#include "godialog.h"
#include "finddialog.h"
#include<QFileDialog>
#include<QTextStream>
#include<QSettings>
#include<QApplication>
#include<QLineEdit>



SpreadSheet::SpreadSheet(QWidget *parent)
    : QMainWindow(parent)
{
    spreadsheet = new QTableWidget;
    spreadsheet->setRowCount(200);
    spreadsheet->setColumnCount(100);
    setCentralWidget(spreadsheet);

    createActions();
    createMenus();
    createtoolbar();

    makeconnexions();

    //creating the labels dor the satus bar (should be in its proper function)
    celllocation= new QLabel("A4");
    cellformula = new QLabel("");
    statusBar()->addPermanentWidget(celllocation);
   statusBar()->addPermanentWidget(cellformula);

   QStringList labels;
   for(char letter = 'A'; letter<= 'Z'; letter++)
   {
       labels << QString{letter};

   }
   spreadsheet->setVerticalHeaderLabels(labels);

   currentFile= nullptr;
   setWindowTitle("Buffer");

}

SpreadSheet::~SpreadSheet()
{
    delete spreadsheet;
    delete  newfile;
    delete savefile;
    delete open;
    delete cutfile;
    delete quit;
    delete aboutme;
    delete aboutqt;
    delete saveas;
    delete Copy;
    delete Paste;
    delete find;
    delete delet;
    delete gotocell;
    delete recalculate;
    delete sort;
    delete row;
    delete column;
    delete all;
    delete showgrid;
    delete autorecalculate;
    delete search;
    delete filemenu;
    delete helpmenu;
    delete tools;
    delete options;
    delete edit;
    delete select;
    delete celllocation;
    delete cellformula;
    delete currentFile;
    delete recentFilesMenu;
    delete ouvrir;
    delete opencsv;


}
void SpreadSheet::createActions(){


    // etape1 : choisir une icone
    QPixmap quitIcon(":/icons/quit_icon.png");
    QPixmap newIcon(":/icons/new_file.png");
    QPixmap cutIcon(":/icons/cut_icon.png");
    QPixmap searchIcon(":/icons/search_icon.png");
    QPixmap saveIcon(":/icons/save_file.png");
    QPixmap saveAsIcon(":/icons/saveas.png");
    QPixmap copyIcon(":/icons/copy.jpg");
    QPixmap pasteIcon(":/icons/paste.png");
    QPixmap openIcon(":/icons/open.jpg");

    // etape2 : creer l action
    quit = new QAction(quitIcon, "&Quit", this);
    savefile = new QAction(saveIcon, "&Save", this);
    saveas = new QAction(saveAsIcon,"&Save &As...", this );
    Copy = new QAction(copyIcon,"&Copy", this);
    Paste = new QAction(pasteIcon,"&Paste", this);
    find = new QAction("&Find", this);
    gotocell = new QAction("&Go to Cell", this);
    delet = new QAction("&Delete", this);
    row = new QAction("&Row", this);
    column = new QAction("&Column", this);
    all = new QAction("&All", this);
    recalculate = new QAction("&Recalculate", this);
    sort = new QAction("&Sort", this);
    showgrid = new QAction("&Show Grid",this);
    showgrid->setCheckable(true);
    showgrid->setChecked(spreadsheet->showGrid());

    autorecalculate = new QAction("&Auto-recalculate", this);
    autorecalculate->setCheckable(true);

    newfile = new QAction(newIcon, "&New", this);
    cutfile = new QAction(cutIcon, "&Cut", this);
    search = new QAction(searchIcon,"&Search", this);
    aboutme = new QAction("&About" , this);
    aboutqt = new QAction("&About Qt", this);
    open = new QAction(openIcon,"&Open coordinate file", this);
    opencsv = new QAction(openIcon,"&Open a CSV file",this);







    //etape 3: choisir un raccourci
    quit->setShortcut(tr("Ctrl+Q"));
    newfile->setShortcut(tr("Ctrl+N"));
    cutfile->setShortcut(tr("Ctrl+U"));
    search->setShortcut(tr("Ctrl+S"));
    Paste->setShortcut(tr("Ctrl+V"));
    Copy->setShortcut(tr("Ctrl+C"));
    delet->setShortcut(tr("Del"));
    gotocell->setShortcut(tr("F5"));
    all->setShortcut(tr("Ctrl+A"));
    recalculate->setShortcut(tr("F9"));
    open->setShortcut(tr("Ctrl+O"));
    savefile->setShortcut(tr("Ctrl+S"));


    //etape4: choisir un slot sur makeConnexions



}
void SpreadSheet::createMenus(){

    filemenu = menuBar()->addMenu("&File");
    filemenu->addAction(newfile);
    ouvrir =filemenu->addMenu("&Open");
    ouvrir->addAction(open);
    ouvrir->addAction(opencsv);

    recentFilesMenu = filemenu->addMenu(tr("Open Recent"));



    filemenu->addAction(savefile);
    filemenu->addAction(saveas);
    filemenu->addSeparator();

    filemenu->addSeparator();
    filemenu->addAction(quit);



    edit = menuBar()->addMenu("&Edit");
    edit->addAction(cutfile);
    edit->addAction(Copy);
    edit->addAction(Paste);
    edit->addAction(delet);


    select = edit->addMenu("&Select");
    select->addAction(row);
    select->addAction(column);
    select->addAction(all);
    edit->addSeparator();
    edit->addAction(find);
    edit->addAction(gotocell);


    tools = menuBar()->addMenu("&Tools");
    tools->addAction(recalculate);
    tools->addAction(sort);


    options = menuBar()->addMenu("&Options");
    options->addAction(showgrid);
    options->addAction(autorecalculate);




    helpmenu = menuBar()->addMenu("&Help");
    helpmenu->addAction(aboutme);
    helpmenu->addAction(aboutqt);




}
void SpreadSheet::aboutqtslot(){
    QMessageBox::aboutQt(this, "About Me");
}

void SpreadSheet::createtoolbar(){
    auto toolbar1= addToolBar("Tool Bar 1");
    toolbar1->addAction(quit);
    toolbar1->addAction(cutfile);
    toolbar1->addAction(Copy);
    toolbar1->addAction(Paste);
    toolbar1->addAction(open);
    toolbar1->addAction(savefile);

    auto toolbar2 = addToolBar("Tool Bar 2");
    toolbar2->addAction(aboutqt);

}
void SpreadSheet::updateStatusBar(int row, int col){
//    celllocation= new QLabel("A4");
//    cellformula = new QLabel("A3 +A2");
//    statusBar()->addPermanentWidget(celllocation);
//   statusBar()->addPermanentWidget(cellformula);
    QString cell{"(%0,%1)"};
    celllocation->setText(cell.arg(row+1).arg(col+1));
   statusBar()->showMessage("Opening File", 5000);
}
void SpreadSheet::makeconnexions(){
    connect(spreadsheet, &QTableWidget::cellClicked, this, &SpreadSheet::updateStatusBar );
    connect(quit, &QAction::triggered, this, &QMainWindow::close);
    connect(aboutqt, &QAction::triggered, this, &SpreadSheet::aboutqtslot);
    connect(newfile, &QAction::triggered, spreadsheet, &QTableWidget::clear);
    connect(all, &QAction::triggered, spreadsheet, &QTableWidget::selectAll);


    connect(cutfile, &QAction ::triggered, this, &SpreadSheet::cutSlot);
    connect(Copy, &QAction ::triggered, this, &SpreadSheet::copySlot);
    connect(Paste, &QAction ::triggered, this, &SpreadSheet::pasteSlot);
    connect(showgrid, &QAction::triggered, spreadsheet, &QTableWidget::setShowGrid);

    connect(gotocell, &QAction::triggered, this, &SpreadSheet::goCellSlot);
   connect(find, &QAction::triggered, this, &SpreadSheet::findSlot);

   connect(savefile, &QAction::triggered, this , &SpreadSheet::saveSlot);
   connect(saveas, &QAction::triggered, this , &SpreadSheet::saveascsvslot);
   connect(open, &QAction::triggered, this, &SpreadSheet::loadFileSlot);
   connect(opencsv, &QAction::triggered, this, &SpreadSheet::loadCsvFileSlot);


}
void SpreadSheet::goCellSlot(){
    // creer un dialog
    GoDialog d;
     //executer le dialog
    auto reply=d.exec();

    //verifier si le dialog a ete acceplte
    if(reply == GoDialog::Accepted)
    {


        // extraire le text
        QString cell = d.getCell();
        //extraire la ligne

        int row =  cell[0].toLatin1()- 'A';

        //Extraire la colonne

        cell = cell.remove(0,1);
        int col = cell.toInt()-1;

        // changer la cellule
        statusBar()->showMessage("Changing the current cell" , 2000);
        spreadsheet->setCurrentCell(row, col);


     }

}
void SpreadSheet::findSlot(){
    FindDialog dialog;
     auto reply= dialog.exec();
     auto found= false;

     if(reply == FindDialog::Accepted)
     {
         QString text= dialog.getText();
         for(auto i=0; i<spreadsheet->rowCount(); i++)
         {
             for(auto j=0; j<spreadsheet->columnCount(); j++)
             {
                 if(spreadsheet->item(i,j))
                 {
                   QString searchword = spreadsheet->item(i,j)->text();
                    if(searchword.contains(text))
                    {
                        spreadsheet->setCurrentCell(i,j);
                        found= true;



                    }


                }
}
         }
         if(!found)
               QMessageBox::information(this, "Error", "No such word or expression");


     }
     }
void SpreadSheet::saveSlot(){
    // tester si on possede un nom de fichier
    if(!currentFile)
    {
        //creer Factory design
        QFileDialog d;

        // creer un dialog pour obtenir le nom de fichier
        auto filename = d.getSaveFileName();

        //ajouter le fichier enregiste a recentFiles et creer la connexion
        recentFilesList.append(new QAction(filename,this));
        recentFilesMenu->addAction(recentFilesList[i]);

        connect(recentFilesList[i],&QAction::triggered,this,&SpreadSheet::openRecent);
        i++;
        // changer le nom du fichier courant
        currentFile = new QString(filename);
        // mettre a jour le titre de le fenetre
        setWindowTitle(*currentFile);

    }
    // sauvegarder le contenu
    saveContent(*currentFile);


}
void SpreadSheet::saveascsvslot() {
// tester si on possede un nom de fichier
if(!currentFile)
{
    //creer Factory design
    QFileDialog d;

    // creer un dialog pour obtenir le nom de fichier
    auto filename = d.getSaveFileName();

    //ajouter le fichier enregiste a recentFiles et creer la connexion
    recentFilesList.append(new QAction(filename,this));
    recentFilesMenu->addAction(recentFilesList[i]);

    connect(recentFilesList[i],&QAction::triggered,this,&SpreadSheet::openRecent);
    i++;
    // changer le nom du fichier courant
    currentFile = new QString(filename);
    // mettre a jour le titre de le fenetre
    setWindowTitle(*currentFile);

}
// sauvegarder le contenu
saveascsvContent(*currentFile);

}
void SpreadSheet::saveContent(QString filename) {

    //syntax c++
    // ofstream out(filename); .... out.close();

    // syntax c
    // FILE *fid =fopen(filename, "w") ..... fclose(fid)

    //en qt
    //1 pointeur sur le fichier d interet
    QFile file(filename);

    //2 ouvrir le fichier en mode write
    if(file.open(QIODevice::WriteOnly))
    {
        QTextStream out(&file);

         //parcourir les cellules et sauvegarder leur contenu
        for (int i=0;i<spreadsheet->rowCount() ;i++ ) {
            for(int j=0; j<spreadsheet->columnCount();j++){
                auto cell = spreadsheet->item(i,j);
                if(cell)
                    out << i<< "," << j << "," << cell->text() << Qt::endl;
            }

        }
    }



    // fermer le fichier
    file.close();



}
void SpreadSheet::saveascsvContent(QString filename) {
    QFile file(filename);

   int rows = spreadsheet->rowCount();
   int columns = spreadsheet->columnCount();
   if(file.open(QIODevice::WriteOnly )) {

       QTextStream out(&file);


   for (int i = 0; i < rows; i++) {
       for (int j = 0; j < columns; j++) {

           auto cell = spreadsheet->item(i,j);
           if(cell)
               out<< cell->text()<<",";
           else
               out<< " "<<",";

       }
        out<< Qt::endl;

   }


   file.close();
}
}
void SpreadSheet::loadFileSlot(){

        QFileDialog d;
        auto filename = d.getOpenFileName();

        //ajouter le fichier qu'on vient d'ouvrir a recentFiles et creer la connexion
        recentFilesList.append(new QAction(filename,this));
        recentFilesMenu->addAction(recentFilesList[i]);

        connect(recentFilesList[i],&QAction::triggered,this,&SpreadSheet::openRecent);
        i++;
        if(filemenu)

       {
            currentFile = new QString(filename);
            setWindowTitle(*currentFile);

           openContent(*currentFile);

        }

}
void SpreadSheet::loadCsvFileSlot(){

        QFileDialog d;
        auto filename = d.getOpenFileName();

        //ajouter le fichier qu'on vient d'ouvrir a recentFiles et creer la connexion
        recentFilesList.append(new QAction(filename,this));
        recentFilesMenu->addAction(recentFilesList[i]);

        connect(recentFilesList[i],&QAction::triggered,this,&SpreadSheet::openRecent);
        i++;
        if(filemenu)

       {
            currentFile = new QString(filename);
            setWindowTitle(*currentFile);

           openCsvContent(*currentFile);

        }

}
void SpreadSheet::openContent(QString filename) {
    //open coordinate file
    // obtenir le fichier
    QFile file(filename);
    QString line;
     if(file.open(QIODevice::ReadOnly))
     {
         QTextStream in(&file);
         while( !in.atEnd())
         {
             line = in.readLine();
             auto tokens = line.split(QChar(',') );
             int row = tokens[0].toInt();
             int col = tokens[1].toInt();
             spreadsheet->setItem(row, col , new QTableWidgetItem(tokens[2]));
         }


     }

     file.close();




}
void SpreadSheet::openCsvContent(QString filename){
         //open csv file
         QFile file(filename);
         QStringList list;
         int count = 0;
          if(file.open(QIODevice::ReadOnly))
          {
              QTextStream in(&file);

              while( !in.atEnd())
              {
                  QString line = in.readLine();
                  for(auto content : line.split(","))
                      list.append(content);
                  for(auto i =0; i<list.length(); i++)
                      spreadsheet->setItem(count,i, new QTableWidgetItem(list[i]));
                 count++;
                 list.clear();
              }


          }
         file.close();

}

void SpreadSheet::openRecent(){
    QAction *action = qobject_cast<QAction *>(sender());
    if (action)
    {
        openContent(action->text());
        saveContent(action->text());
        saveascsvContent(action->text());
    }

}

void SpreadSheet::copySlot(){

     QLineEdit* lineEdit = dynamic_cast<QLineEdit*>(focusWidget());
     if (lineEdit)
     {

         lineEdit->copy();
     }
}
void SpreadSheet::cutSlot(){
    QLineEdit* lineEdit = dynamic_cast<QLineEdit*>(focusWidget());
      if (lineEdit)
      {
          lineEdit->cut();
      }
}
void SpreadSheet::pasteSlot(){
      QLineEdit* lineEdit = dynamic_cast<QLineEdit*>(focusWidget());
      if (lineEdit)
      {
          lineEdit->paste();
      }
}
