#ifndef SPREADSHEET_H
#define SPREADSHEET_H

#include <QMainWindow>
#include<QTableWidget>
#include<QAction>
#include<QMenu>
#include<QMenuBar>
#include<QToolBar>
#include<QLabel>


class SpreadSheet : public QMainWindow
{
    Q_OBJECT

public:
    SpreadSheet(QWidget *parent = nullptr);
    ~SpreadSheet();
    int i=0;
protected:

   void createActions();
   void createMenus();
   void createtoolbar();
   void updatestatusbar();
   void makeconnexions();
   void saveContent(QString filename);
   void saveascsvContent(QString filename);
   void openContent(QString filename);
   void openCsvContent(QString filename);






private:
    QTableWidget *spreadsheet;
    QAction *newfile;
    QAction *savefile;
    QAction *open;
    QAction *opencsv;
    QAction *cutfile;
    QAction *quit;
    QAction *aboutme;
    QAction *aboutqt;
    QAction *saveas;
    QAction *Copy ;
    QAction *Paste;
    QAction *find;
    QAction *delet;

    QAction *gotocell;
    QAction *recalculate;
    QAction *sort;
    QAction *row;
    QAction *column;
    QAction *all;
    QAction *showgrid;
    QAction *autorecalculate;
    QAction *search;


    QList<QAction*> recentFilesList;


    QMenu *filemenu;
    QMenu *helpmenu;
    QMenu *tools;
    QMenu *options;
     QMenu *edit;
     QMenu *select;
      QMenu* recentFilesMenu;
      QMenu* ouvrir;



     QLabel *celllocation;
     QLabel *cellformula;


     QString *currentFile;





private slots:
  void  aboutqtslot();
  void updateStatusBar(int,int);
  void goCellSlot();
 void findSlot();
 void saveSlot();
 void saveascsvslot();
 void loadFileSlot();
  void openRecent();
  void loadCsvFileSlot();
void copySlot();
void cutSlot();
void pasteSlot();






};
#endif // SPREADSHEET_H
